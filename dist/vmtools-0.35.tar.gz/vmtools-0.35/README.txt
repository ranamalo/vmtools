Right now the only tool here helps you get the python virtual environment root.  I use it to be able to find a common settings file.
