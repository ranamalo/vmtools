from __future__ import absolute_import
from vmtools.vmtools import  get_time
from vmtools.vmtools import  vm_root_grabber
